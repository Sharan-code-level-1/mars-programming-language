x = pi / 4

y = sin(x)

print(y,float)

a = sind(30)

print(a,float)

b = 2 ^ 8

print(b,int)

c = sqrt(16) + exp(1)

print(c,float)

d = sin(x)^2 + cos(x)^2

print(d,float)
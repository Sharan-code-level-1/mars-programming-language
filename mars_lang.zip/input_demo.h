print(0, int)
read x
print(x, int)
print(x, float)

if x > 10:
    print(x, float)
else:
    print(x, float)

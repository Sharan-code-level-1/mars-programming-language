#include "mars.h"
#include <ctype.h>

char lexeme[64];
TokenType currTok;
const char *src = NULL;

void advance(void)
{

    while (*src && isspace(*src))
        src++;

    if (*src == '\0') {
        currTok = TOK_EOF;
        return;
    }

    if (isalpha(*src) || *src == '_')
    {

        int i = 0;

        while (isalnum(*src) || *src == '_')
            lexeme[i++] = *src++;

        lexeme[i] = '\0';

        if (!strcmp(lexeme,"if")) currTok = TOK_IF;
        else if (!strcmp(lexeme,"else")) currTok = TOK_ELSE;
        else if (!strcmp(lexeme,"while")) currTok = TOK_WHILE;
        else if (!strcmp(lexeme,"print")) currTok = TOK_PRINT;
        else if (!strcmp(lexeme,"read")) currTok = TOK_READ;

        else if (!strcmp(lexeme,"sin")) currTok = TOK_SIN;
        else if (!strcmp(lexeme,"cos")) currTok = TOK_COS;
        else if (!strcmp(lexeme,"tan")) currTok = TOK_TAN;

        else if (!strcmp(lexeme,"sind")) currTok = TOK_SIND;
        else if (!strcmp(lexeme,"cosd")) currTok = TOK_COSD;
        else if (!strcmp(lexeme,"tand")) currTok = TOK_TAND;

        else if (!strcmp(lexeme,"exp")) currTok = TOK_EXP;
        else if (!strcmp(lexeme,"log")) currTok = TOK_LOG;
        else if (!strcmp(lexeme,"sqrt")) currTok = TOK_SQRT;
        else if (!strcmp(lexeme,"abs")) currTok = TOK_ABS;

        else if (!strcmp(lexeme,"pi")) {
            strcpy(lexeme,"3.141592653589793");
            currTok = TOK_NUM;
        }

        else currTok = TOK_ID;

        return;
    }

    if (isdigit(*src) || (*src=='.' && isdigit(src[1])))
    {

        int i=0;

        while(isdigit(*src) || *src=='.')
            lexeme[i++]=*src++;

        lexeme[i]='\0';

        currTok=TOK_NUM;

        return;
    }

    switch(*src)
    {
        case '=': currTok=TOK_EQUALS; break;
        case ':': currTok=TOK_COLON; break;
        case ',': currTok=TOK_COMMA; break;

        case '(': currTok=TOK_LPAREN; break;
        case ')': currTok=TOK_RPAREN; break;

        case '{': currTok=TOK_LBRACE; break;
        case '}': currTok=TOK_RBRACE; break;

        case '+': currTok=TOK_PLUS; break;
        case '-': currTok=TOK_MINUS; break;
        case '*': currTok=TOK_MUL; break;
        case '/': currTok=TOK_DIV; break;
        case '^': currTok=TOK_POW; break;

        case '>': currTok=TOK_GT; break;
        case '<': currTok=TOK_LT; break;

        default:
            src++;
            currTok=TOK_EOF;
            return;
    }

    src++;
}
#ifndef MARS_H
#define MARS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef enum {
    TOK_ID,       // identifier
    TOK_NUM,      // numeric literal
    TOK_STR,      // string literal

    // Keywords
    TOK_IF,
    TOK_ELSE,
    TOK_WHILE,
    TOK_PRINT,
    TOK_INT,
    TOK_FLOAT,
    TOK_STRING,

    // Symbols / operators
    TOK_EQUALS,   // =
    TOK_COLON,    // :
    TOK_COMMA,    // ,
    TOK_LPAREN,   // (
    TOK_RPAREN,   // )
    TOK_PLUS,     // +
    TOK_MINUS,    // -
    TOK_MUL,      // *
    TOK_DIV,      // /
    TOK_GT,       // >
    TOK_LT,       // <
    TOK_LBRACE,   // {
    TOK_RBRACE,   // }

    TOK_EOF       // end of input
} TokenType;

/* -------- AST node kinds -------- */
typedef enum {
    ND_ASSIGN,
    ND_IF,
    ND_WHILE,
    ND_PRINT,
    ND_VAR,
    ND_NUM,
    ND_ADD,
    ND_SUB,
    ND_MUL,
    ND_DIV,
    ND_GT,
    ND_LT
} NodeKind;

/* -------- AST node -------- */
typedef struct Node {
    NodeKind kind;
    struct Node *cond;
    struct Node *left;
    struct Node *right;
    struct Node *next;
    char  name[64];
    double val;
    int   targetType;
} Node;

/* -------- Lexer globals -------- */
extern char      lexeme[64];
extern TokenType currTok;
extern const char *src;

/* -------- API -------- */
void advance(void);
Node *parse_stmt(void);   /* fixed name */
double execute(Node *n);

#endif

#include "mars.h"

struct {
    char name[64];
    double val;
} sym[100];

int count=0;

void setv(char*name,double v)
{
    for(int i=0;i<count;i++)
        if(!strcmp(sym[i].name,name))
        {
            sym[i].val=v;
            return;
        }

    strcpy(sym[count].name,name);
    sym[count].val=v;
    count++;
}

double getv(char*name)
{
    for(int i=0;i<count;i++)
        if(!strcmp(sym[i].name,name))
            return sym[i].val;

    return 0;
}

double execute(Node*n)
{
    double r=0;

    while(n)
    {
        switch(n->kind)
        {

            case ND_NUM:r=n->val;break;

            case ND_VAR:r=getv(n->name);break;

            case ND_ADD:r=execute(n->left)+execute(n->right);break;
            case ND_SUB:r=execute(n->left)-execute(n->right);break;
            case ND_MUL:r=execute(n->left)*execute(n->right);break;
            case ND_DIV:r=execute(n->left)/execute(n->right);break;

            case ND_POW:r=pow(execute(n->left),execute(n->right));break;

            case ND_GT:r=execute(n->left)>execute(n->right);break;
            case ND_LT:r=execute(n->left)<execute(n->right);break;

            case ND_ASSIGN:
                r=execute(n->right);
                setv(n->name,r);
                break;

            case ND_PRINT:

                r=execute(n->left);

                if(n->targetType==1)
                    printf("%d\n",(int)r);
                else
                    printf("%.4f\n",r);

                break;

            case ND_READ:
            {
                double x;
                scanf("%lf",&x);
                setv(n->name,x);
                break;
            }

            case ND_SIN:r=sin(execute(n->left));break;
            case ND_COS:r=cos(execute(n->left));break;
            case ND_TAN:r=tan(execute(n->left));break;

            case ND_SIND:r=sin(execute(n->left)*M_PI/180.0);break;
            case ND_COSD:r=cos(execute(n->left)*M_PI/180.0);break;
            case ND_TAND:r=tan(execute(n->left)*M_PI/180.0);break;

            case ND_EXP:r=exp(execute(n->left));break;
            case ND_LOG:r=log(execute(n->left));break;
            case ND_SQRT:r=sqrt(execute(n->left));break;
            case ND_ABS:r=fabs(execute(n->left));break;

        }

        n=n->next;
    }

    return r;
}
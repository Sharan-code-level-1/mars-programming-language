#include "mars.h"

int main(int argc,char*argv[])
{

    FILE *f;
    long len;

    char *buffer;

    if(argc<2)
    {
        printf("usage: mars program.m\n");
        return 1;
    }

    f=fopen(argv[1],"rb");

    fseek(f,0,SEEK_END);
    len=ftell(f);
    rewind(f);

    buffer=malloc(len+1);

    fread(buffer,1,len,f);

    buffer[len]='\0';

    fclose(f);

    src=buffer;

    advance();

    while(currTok!=TOK_EOF)
    {
        Node*tree=parse_stmt();

        if(tree)
            execute(tree);
    }

    free(buffer);

    return 0;
}
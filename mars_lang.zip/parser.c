#include "mars.h"

static Node* create_node(NodeKind k)
{
    Node* n=calloc(1,sizeof(Node));
    n->kind=k;
    return n;
}

static Node* parse_expr();

static Node* parse_factor()
{
    Node* n;

    if(currTok==TOK_NUM)
    {
        n=create_node(ND_NUM);
        n->val=atof(lexeme);
        advance();
        return n;
    }

    if(currTok==TOK_ID)
    {
        n=create_node(ND_VAR);
        strcpy(n->name,lexeme);
        advance();
        return n;
    }

    if(currTok==TOK_LPAREN)
    {
        advance();
        n=parse_expr();
        if(currTok==TOK_RPAREN) advance();
        return n;
    }

    if(currTok>=TOK_SIN && currTok<=TOK_ABS)
    {
        NodeKind k;

        switch(currTok)
        {
            case TOK_SIN:k=ND_SIN;break;
            case TOK_COS:k=ND_COS;break;
            case TOK_TAN:k=ND_TAN;break;

            case TOK_SIND:k=ND_SIND;break;
            case TOK_COSD:k=ND_COSD;break;
            case TOK_TAND:k=ND_TAND;break;

            case TOK_EXP:k=ND_EXP;break;
            case TOK_LOG:k=ND_LOG;break;
            case TOK_SQRT:k=ND_SQRT;break;
            default:k=ND_ABS;
        }

        n=create_node(k);

        advance();
        advance();

        n->left=parse_expr();

        if(currTok==TOK_RPAREN) advance();

        return n;
    }

    return NULL;
}

static Node* parse_power()
{
    Node* left=parse_factor();

    while(currTok==TOK_POW)
    {
        Node* n=create_node(ND_POW);
        advance();
        n->left=left;
        n->right=parse_factor();
        left=n;
    }

    return left;
}

static Node* parse_term()
{
    Node* left=parse_power();

    while(currTok==TOK_MUL || currTok==TOK_DIV)
    {
        Node* n=create_node(currTok==TOK_MUL?ND_MUL:ND_DIV);
        advance();
        n->left=left;
        n->right=parse_power();
        left=n;
    }

    return left;
}

static Node* parse_expr()
{
    Node* left=parse_term();

    while(currTok==TOK_PLUS||currTok==TOK_MINUS||currTok==TOK_GT||currTok==TOK_LT)
    {
        NodeKind k;

        if(currTok==TOK_PLUS)k=ND_ADD;
        else if(currTok==TOK_MINUS)k=ND_SUB;
        else if(currTok==TOK_GT)k=ND_GT;
        else k=ND_LT;

        Node* n=create_node(k);
        advance();

        n->left=left;
        n->right=parse_term();

        left=n;
    }

    return left;
}

Node* parse_stmt()
{

    if(currTok==TOK_ID)
    {
        Node* n=create_node(ND_ASSIGN);

        strcpy(n->name,lexeme);
        advance();

        advance();

        n->right=parse_expr();

        return n;
    }

    if(currTok==TOK_PRINT)
    {
        Node* n=create_node(ND_PRINT);

        advance();
        advance();

        n->left=parse_expr();

        if(currTok==TOK_COMMA)
        {
            advance();

            if(currTok==TOK_INT)
                n->targetType=1;
            else
                n->targetType=2;

            advance();
        }

        if(currTok==TOK_RPAREN) advance();

        return n;
    }

    if(currTok==TOK_READ)
    {
        Node* n=create_node(ND_READ);

        advance();

        strcpy(n->name,lexeme);
        advance();

        return n;
    }

    return NULL;
}
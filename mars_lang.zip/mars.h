#ifndef MARS_H
#define MARS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

/* -------- Tokens -------- */

typedef enum {

    TOK_ID,
    TOK_NUM,

    TOK_IF,
    TOK_ELSE,
    TOK_WHILE,
    TOK_PRINT,
    TOK_READ,

    TOK_INT,
    TOK_FLOAT,

    TOK_SIN,
    TOK_COS,
    TOK_TAN,

    TOK_SIND,
    TOK_COSD,
    TOK_TAND,

    TOK_EXP,
    TOK_LOG,
    TOK_SQRT,
    TOK_ABS,

    TOK_EQUALS,
    TOK_COLON,
    TOK_COMMA,

    TOK_LPAREN,
    TOK_RPAREN,
    TOK_LBRACE,
    TOK_RBRACE,

    TOK_PLUS,
    TOK_MINUS,
    TOK_MUL,
    TOK_DIV,
    TOK_POW,

    TOK_GT,
    TOK_LT,

    TOK_EOF

} TokenType;


/* -------- AST nodes -------- */

typedef enum {

    ND_ASSIGN,
    ND_IF,
    ND_WHILE,
    ND_PRINT,
    ND_READ,

    ND_VAR,
    ND_NUM,

    ND_ADD,
    ND_SUB,
    ND_MUL,
    ND_DIV,
    ND_POW,

    ND_GT,
    ND_LT,

    ND_SIN,
    ND_COS,
    ND_TAN,

    ND_SIND,
    ND_COSD,
    ND_TAND,

    ND_EXP,
    ND_LOG,
    ND_SQRT,
    ND_ABS

} NodeKind;


/* -------- AST structure -------- */

typedef struct Node {

    NodeKind kind;

    struct Node *cond;
    struct Node *left;
    struct Node *right;
    struct Node *next;

    char name[64];

    double val;

    int targetType;

} Node;


/* -------- lexer globals -------- */

extern char lexeme[64];
extern TokenType currTok;
extern const char *src;


/* -------- API -------- */

void advance(void);
Node *parse_stmt(void);
double execute(Node *n);

#endif